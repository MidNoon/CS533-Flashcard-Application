package com.example.empty;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ExampleFragment extends Fragment {

    public ExampleFragment(){

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_example, container, false);

    }


    //public ExampleFragment() {
        // Required empty public constructor
    //}

    //@Override
    //public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        //View view = inflater.inflate(R.layout.fragment_example, container, true);
        //Button man = (Button) view.findViewById(R.id.MinusButton);
        //man.setOnClickListener(new View.OnClickListener(){
        //    @Override
        //    public void onClick(View v) {
        //        Intent intent = new Intent(getActivity(), MainActivity.class);
        //        getActivity().startActivity(intent);
        //        getActivity().overridePendingTransition(R.anim.right_in, R.anim.left_out);
        //    }
        //});
     //   return view;
   //}


        //Button Saver = (Button) tom.findViewById(R.id.Saver);

        //Button mutton = (Button) view.findViewById(R.id.MinusButton);
        //mutton.setOnClickListener(new OnClickListener() {

        //view.findViewById(R.id.MinusButton).setOnClickListener(new OnClickListener() {


    //public void onButtonClicked(View v) {
     //   Intent intent = new Intent(getActivity(), MainActivity.class);
     //   getActivity().startActivity(intent);
      //  getActivity().overridePendingTransition(R.anim.right_in, R.anim.left_out);
   // }

   // @Override
  //  public void onClick(View view) {

 //   }
    //});


        //getView().findViewById(R.id.SaveButton).setOnClickListener(new View.OnClickListener() {
        //    @Override
        //    public void onClick(View v) {
        //
        //        String newQuestion = ((EditText)getView().findViewById(R.id.editText)).getText().toString();
        //        String newAnswer = ((EditText)getView().findViewById(R.id.editText2)).getText().toString();
        //        Intent data = new Intent();
        //        data.putExtra("string1", newQuestion);
        //        data.putExtra("string2", newAnswer);
        //        getActivity().setResult(AddCardActivity.RESULT_OK, data);
        //        getActivity().finish();
        //    }
        //});
}