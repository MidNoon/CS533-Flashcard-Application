package com.example.empty;

import android.app.Activity;
import android.os.Bundle;

public class AAT extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a_a_t);
    }
}